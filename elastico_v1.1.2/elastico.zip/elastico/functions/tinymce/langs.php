<?php 
$strings = "tinyMCE.addI18n({en:{
theme_shortcodes:{desc : 'Add Custom Shortcode'},}});";
?>